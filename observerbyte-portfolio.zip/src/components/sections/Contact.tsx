import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Mail, Phone, MessageCircle, Send, Instagram } from 'lucide-react';
import toast from 'react-hot-toast';
import Section from '@/components/common/Section';
import SectionHeader from '@/components/common/SectionHeader';
import Button from '@/components/ui/Button';
import { contactService } from '@/services/api';
import { siteConfig } from '@/data/siteData';

const contactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  subject: z.string().min(5, 'Subject must be at least 5 characters'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

type ContactFormData = z.infer<typeof contactSchema>;

export default function Contact() {
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
  });

  const onSubmit = async (data: ContactFormData) => {
    setLoading(true);
    try {
      await contactService.sendMessage(data);
      toast.success("Message sent successfully! I'll get back to you soon.");
      reset();
    } catch (error) {
      toast.error('Failed to send message. Please try again or contact me directly.');
    } finally {
      setLoading(false);
    }
  };

  const contactMethods = [
    { icon: Mail, label: 'Email', value: siteConfig.email, href: `mailto:${siteConfig.email}` },
    { icon: Phone, label: 'Phone', value: siteConfig.phone[0], href: `tel:${siteConfig.phone[0]}` },
    { icon: MessageCircle, label: 'WhatsApp', value: 'Chat on WhatsApp', href: `https://wa.me/${siteConfig.whatsapp}` },
  ];

  return (
    <Section id="contact">
      <SectionHeader label="Get In Touch" title="Let's Work Together" description="Have a project in mind? Let's discuss how I can help" />
      <div className="grid lg:grid-cols-5 gap-12">
        <div className="lg:col-span-2 space-y-6">
          {contactMethods.map((method, i) => (
            <a
              key={i}
              href={method.href}
              target={method.label === 'WhatsApp' ? '_blank' : undefined}
              rel={method.label === 'WhatsApp' ? 'noopener noreferrer' : undefined}
              className="flex items-start gap-4 p-6 bg-white dark:bg-dark-800 rounded-xl border border-dark-100 dark:border-dark-700 hover:border-gold-500 transition-colors group"
            >
              <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center text-gold-500 group-hover:bg-gold-500 group-hover:text-dark-900 transition-colors">
                <method.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">{method.label}</h3>
                <p className="text-dark-500 dark:text-gray-400">{method.value}</p>
              </div>
            </a>
          ))}

          <div className="pt-6">
            <h3 className="font-semibold mb-4">Follow Me</h3>
            <div className="flex gap-3">
              <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-dark-100 dark:bg-dark-700 rounded-lg flex items-center justify-center text-gold-500 hover:bg-gold-500 hover:text-dark-900 transition-all">
                <Instagram className="w-6 h-6" />
              </a>
              <a href={siteConfig.social.tiktok} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-dark-100 dark:bg-dark-700 rounded-lg flex items-center justify-center text-gold-500 hover:bg-gold-500 hover:text-dark-900 transition-all">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                </svg>
              </a>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="lg:col-span-3 bg-white dark:bg-dark-800 p-8 rounded-2xl border border-dark-100 dark:border-dark-700 space-y-6">
          <div className="grid sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Full Name</label>
              <input {...register('name')} type="text" className="w-full px-4 py-3 bg-dark-50 dark:bg-dark-700 border border-dark-200 dark:border-dark-600 rounded-lg focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 outline-none" placeholder="John Doe" />
              {errors.name && <p className="mt-1 text-sm text-red-500">{errors.name.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Email Address</label>
              <input {...register('email')} type="email" className="w-full px-4 py-3 bg-dark-50 dark:bg-dark-700 border border-dark-200 dark:border-dark-600 rounded-lg focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 outline-none" placeholder="john@example.com" />
              {errors.email && <p className="mt-1 text-sm text-red-500">{errors.email.message}</p>}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Subject</label>
            <input {...register('subject')} type="text" className="w-full px-4 py-3 bg-dark-50 dark:bg-dark-700 border border-dark-200 dark:border-dark-600 rounded-lg focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 outline-none" placeholder="Project Inquiry" />
            {errors.subject && <p className="mt-1 text-sm text-red-500">{errors.subject.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Message</label>
            <textarea {...register('message')} rows={6} className="w-full px-4 py-3 bg-dark-50 dark:bg-dark-700 border border-dark-200 dark:border-dark-600 rounded-lg focus:border-gold-500 focus:ring-2 focus:ring-gold-500/20 outline-none resize-none" placeholder="Tell me about your project..." />
            {errors.message && <p className="mt-1 text-sm text-red-500">{errors.message.message}</p>}
          </div>
          <Button type="submit" variant="primary" size="lg" fullWidth loading={loading} icon={<Send className="w-5 h-5" />}>
            Send Message
          </Button>
        </form>
      </div>
    </Section>
  );
}