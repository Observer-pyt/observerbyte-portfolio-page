import { Star, Quote } from 'lucide-react';
import Section from '@/components/common/Section';
import SectionHeader from '@/components/common/SectionHeader';
import Card3D from '@/components/ui/Card3D';
import { testimonials } from '@/data/siteData';

export default function Testimonials() {
  return (
    <Section id="testimonials" background="alternate">
      <SectionHeader label="Client Feedback" title="What Clients Say" description="Real experiences from satisfied clients" />
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {testimonials.map((testimonial, i) => (
          <Card3D key={i}>
            <div className="bg-white dark:bg-dark-800 p-8 rounded-2xl border border-dark-100 dark:border-dark-700 h-full flex flex-col">
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-gold-500 text-gold-500" />
                ))}
              </div>
              <Quote className="w-10 h-10 text-gold-500/20 mb-4" />
              <p className="text-dark-600 dark:text-gray-300 mb-6 leading-relaxed italic flex-grow">"{testimonial.text}"</p>
              <div className="flex items-center gap-4 pt-6 border-t border-dark-100 dark:border-dark-700">
                <img src={testimonial.avatar} alt={testimonial.author} className="w-12 h-12 rounded-full border-2 border-gold-500" />
                <div>
                  <h4 className="font-semibold">{testimonial.author}</h4>
                  <p className="text-sm text-dark-500 dark:text-gray-400">{testimonial.role}, {testimonial.company}</p>
                </div>
              </div>
            </div>
          </Card3D>
        ))}
      </div>
    </Section>
  );
}