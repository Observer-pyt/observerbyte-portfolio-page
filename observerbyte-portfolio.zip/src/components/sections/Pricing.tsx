import { Check, X } from 'lucide-react';
import Section from '@/components/common/Section';
import SectionHeader from '@/components/common/SectionHeader';
import Card3D from '@/components/ui/Card3D';
import Button from '@/components/ui/Button';
import { pricingPlans, addOns } from '@/data/siteData';
import * as Icons from 'lucide-react';

const iconMap: { [key: string]: any } = {
  'file-text': Icons.FileText,
  'paint-roller': Icons.PaintBucket,
  palette: Icons.Palette,
  tool: Icons.Wrench,
};

export default function Pricing() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <Section id="pricing">
      <SectionHeader label="Investment" title="Pricing Plans" description="Flexible packages designed to fit your budget and needs" />

      <div className="grid md:grid-cols-3 gap-8 mb-16">
        {pricingPlans.map((plan, i) => (
          <Card3D key={plan.id}>
            <div className={`relative p-8 bg-white dark:bg-dark-800 rounded-2xl border h-full flex flex-col ${plan.featured ? 'border-gold-500 shadow-2xl shadow-gold-500/20 scale-105' : 'border-dark-100 dark:border-dark-700'}`}>
              {plan.featured && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-2 bg-gradient-to-r from-gold-400 to-gold-600 text-dark-900 text-sm font-bold rounded-full shadow-lg">
                  Recommended
                </div>
              )}

              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2 text-gold-500">{plan.name}</h3>
                <div className="flex items-baseline justify-center gap-1 mb-2">
                  <span className="text-4xl font-bold text-dark-900 dark:text-white">{plan.price}</span>
                </div>
                <p className="text-dark-500 dark:text-gray-400 text-sm">{plan.description}</p>
              </div>

              <ul className="space-y-3 mb-8 flex-grow">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-gold-500 flex-shrink-0 mt-0.5" />
                    <span className="text-dark-600 dark:text-gray-300 text-sm">{feature}</span>
                  </li>
                ))}
                {plan.disabledFeatures?.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 opacity-40">
                    <X className="w-5 h-5 text-dark-400 flex-shrink-0 mt-0.5" />
                    <span className="text-dark-400 dark:text-gray-500 text-sm line-through">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button variant={plan.featured ? 'primary' : 'outline'} fullWidth onClick={scrollToContact}>
                {plan.cta}
              </Button>
            </div>
          </Card3D>
        ))}
      </div>

      <div className="bg-white dark:bg-dark-800 rounded-2xl p-8 border border-dark-100 dark:border-dark-700">
        <h3 className="text-2xl font-bold text-center mb-8">Add-Ons & Extras</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {addOns.map((addon, i) => {
            const Icon = iconMap[addon.icon] || Icons.Package;
            return (
              <div key={addon.id} className="text-center p-6 bg-dark-50 dark:bg-dark-700 rounded-xl hover:border-gold-500 border border-transparent transition-all">
                <div className="w-12 h-12 mx-auto mb-3 bg-gold-500/10 rounded-lg flex items-center justify-center">
                  <Icon className="w-6 h-6 text-gold-500" />
                </div>
                <h4 className="font-semibold mb-2">{addon.title}</h4>
                <p className="text-xl font-bold text-gold-500">{addon.price}</p>
              </div>
            );
          })}
        </div>
      </div>
    </Section>
  );
}