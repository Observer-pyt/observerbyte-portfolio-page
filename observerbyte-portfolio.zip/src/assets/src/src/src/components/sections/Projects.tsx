import { useNavigate } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';
import Section from '@/components/common/Section';
import SectionHeader from '@/components/common/SectionHeader';
import Card3D from '@/components/ui/Card3D';
import Button from '@/components/ui/Button';
import { projects } from '@/data/projects';

export default function Projects() {
  const navigate = useNavigate();

  return (
    <Section id="projects">
      <SectionHeader label="My Work" title="Featured Projects" description="Explore my latest work and see how I help brands succeed online" />
      <div className="grid md:grid-cols-2 gap-8">
        {projects.map((project) => (
          <Card3D key={project.id}>
            <div className="group relative bg-white dark:bg-dark-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-shadow border border-dark-100 dark:border-dark-700">
              <div className="relative h-64 overflow-hidden bg-gradient-to-br from-dark-100 to-dark-200 dark:from-dark-700 dark:to-dark-800">
                <div className="absolute inset-0 p-6">
                  <div className="relative h-full bg-dark-900 rounded-lg p-2 shadow-2xl">
                    <img src={project.image} alt={project.title} className="w-full h-full object-cover rounded" />
                    <div className="absolute inset-0 bg-gradient-to-t from-gold-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
                <div className="absolute inset-0 bg-dark-900/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button variant="primary" onClick={() => navigate(`/case-study/${project.slug}`)} icon={<ExternalLink className="w-4 h-4" />}>
                    View Case Study
                  </Button>
                </div>
              </div>

              <div className="p-6">
                <div className="flex flex-wrap gap-2 mb-3">
                  {project.tags.map((tag) => (
                    <span key={tag} className="px-3 py-1 text-xs font-medium bg-gold-500/10 text-gold-600 dark:text-gold-400 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-gold-500 transition-colors">{project.title}</h3>
                <p className="text-dark-500 dark:text-gray-400 mb-4 line-clamp-2">{project.shortDescription}</p>
                <button onClick={() => navigate(`/case-study/${project.slug}`)} className="text-gold-500 font-semibold flex items-center gap-2 hover:gap-3 transition-all">
                  View Case Study <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>
          </Card3D>
        ))}
      </div>
    </Section>
  );
}