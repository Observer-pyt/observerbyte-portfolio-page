import { Link } from 'react-router-dom';
import { Instagram, MessageCircle } from 'lucide-react';
import { siteConfig } from '@/data/siteData';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) element.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-dark-100 dark:bg-dark-800 border-t border-dark-200 dark:border-dark-700">
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div>
            <Link to="/" className="text-2xl font-bold">
              <span className="text-dark-900 dark:text-white">Observer</span>
              <span className="text-gold-500">Byte</span>
            </Link>
            <p className="mt-4 text-dark-500 dark:text-gray-400 max-w-sm">
              Building digital experiences that elevate brands
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-3">
              {['about', 'projects', 'services', 'pricing', 'contact'].map((link) => (
                <li key={link}>
                  <button onClick={() => scrollToSection(link)} className="text-dark-500 dark:text-gray-400 hover:text-gold-500 transition-colors capitalize">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Connect</h4>
            <div className="flex gap-3">
              <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-dark-200 dark:bg-dark-700 flex items-center justify-center text-gold-500 hover:bg-gold-500 hover:text-dark-900 transition-all">
                <Instagram className="w-5 h-5" />
              </a>
              <a href={`https://wa.me/${siteConfig.whatsapp}`} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-lg bg-dark-200 dark:bg-dark-700 flex items-center justify-center text-gold-500 hover:bg-gold-500 hover:text-dark-900 transition-all">
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-dark-200 dark:border-dark-700 text-center">
          <p className="text-dark-500 dark:text-gray-400 text-sm">© {currentYear} ObserverByte. All rights reserved.</p>
          <p className="text-dark-400 dark:text-gray-500 text-sm mt-1">Designed & Developed by {siteConfig.fullName}</p>
        </div>
      </div>
    </footer>
  );
}