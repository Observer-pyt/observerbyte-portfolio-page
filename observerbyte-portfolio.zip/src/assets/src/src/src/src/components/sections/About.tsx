import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Section from '@/components/common/Section';
import SectionHeader from '@/components/common/SectionHeader';
import { siteConfig, skills, stats } from '@/data/siteData';
import * as Icons from 'lucide-react';

const iconMap: { [key: string]: any } = {
  html5: Icons.Code,
  css3: Icons.Palette,
  javascript: Icons.FileCode,
  react: Icons.Atom,
  wordpress: Icons.Globe,
  'pencil-ruler': Icons.PenTool,
  palette: Icons.Palette,
  database: Icons.Database,
};

export default function About() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });

  return (
    <Section id="about" background="alternate">
      <SectionHeader label="Get to know me" title="About Me" centered={false} />
      <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
        <motion.div ref={ref} initial={{ opacity: 0, x: -30 }} animate={inView ? { opacity: 1, x: 0 } : {}}>
          <p className="text-xl text-dark-700 dark:text-gray-300 mb-6">
            I'm <strong>{siteConfig.fullName}</strong>, also known as <span className="text-gradient font-semibold">ObserverByte</span>.
          </p>
          <p className="text-dark-500 dark:text-gray-400 mb-6">{siteConfig.aboutBio}</p>

          <div className="grid grid-cols-3 gap-4 mt-8">
            {stats.map((stat, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={inView ? { opacity: 1, y: 0 } : {}} transition={{ delay: 0.2 + i * 0.1 }} className="text-center p-4 bg-white dark:bg-dark-700 rounded-xl">
                <h3 className="text-2xl md:text-3xl font-bold text-gradient">{stat.value}</h3>
                <p className="text-sm text-dark-500 dark:text-gray-400 mt-1">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, x: 30 }} animate={inView ? { opacity: 1, x: 0 } : {}} className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {skills.map((skill, i) => {
            const Icon = iconMap[skill.icon] || Icons.Code;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.3 + i * 0.05 }}
                whileHover={{ y: -5 }}
                className="bg-white dark:bg-dark-700 p-6 rounded-xl text-center border border-dark-100 dark:border-dark-600 hover:border-gold-500 transition-colors group"
              >
                <div className="w-12 h-12 mx-auto mb-3 bg-gold-500/10 rounded-lg flex items-center justify-center text-gold-500 group-hover:bg-gold-500 group-hover:text-dark-900 transition-colors">
                  <Icon className="w-6 h-6" />
                </div>
                <h4 className="font-semibold text-sm">{skill.name}</h4>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </Section>
  );
}
