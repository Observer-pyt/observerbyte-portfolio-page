import Section from '@/components/common/Section';
import SectionHeader from '@/components/common/SectionHeader';
import Card3D from '@/components/ui/Card3D';
import { services } from '@/data/siteData';
import * as Icons from 'lucide-react';

const iconMap: { [key: string]: any } = {
  palette: Icons.Palette,
  code: Icons.Code,
  layers: Icons.Layers,
  'refresh-cw': Icons.RefreshCw,
};

export default function Services() {
  return (
    <Section id="services" background="alternate">
      <SectionHeader label="What I Do" title="Services" description="Comprehensive web solutions tailored to your needs" />
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((service, i) => {
          const Icon = iconMap[service.icon] || Icons.Code;
          return (
            <Card3D key={service.id}>
              <div className={`relative p-6 bg-white dark:bg-dark-800 rounded-2xl border h-full ${service.featured ? 'border-gold-500 shadow-lg shadow-gold-500/20' : 'border-dark-100 dark:border-dark-700 hover:border-gold-500'} transition-all`}>
                {service.featured && (
                  <div className="absolute -top-3 right-4 px-3 py-1 bg-gradient-to-r from-gold-400 to-gold-600 text-dark-900 text-xs font-bold rounded-full">
                    Most Popular
                  </div>
                )}
                <div className="w-16 h-16 bg-gradient-to-br from-gold-400/20 to-gold-600/20 rounded-xl flex items-center justify-center mb-4">
                  <Icon className="w-8 h-8 text-gold-500" />
                </div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-dark-500 dark:text-gray-400 mb-4 text-sm">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-dark-600 dark:text-gray-300">
                      <div className="w-1.5 h-1.5 bg-gold-500 rounded-full" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </Card3D>
          );
        })}
      </div>
    </Section>
  );
}