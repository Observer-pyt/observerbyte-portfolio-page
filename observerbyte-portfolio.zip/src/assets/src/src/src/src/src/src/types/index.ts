export interface Project {
  id: string;
  slug: string;
  title: string;
  shortDescription: string;
  description: string;
  image: string;
  tags: string[];
  client: string;
  timeline: string;
  year: string;
  role: string;
  challenge: string[];
  solution: string[];
  features?: Feature[];
  tools: Tool[];
  results: Result[];
  testimonial?: Testimonial;
  gallery: GalleryImage[];
  beforeImage?: string;
  afterImage?: string;
  nextProject?: {
    title: string;
    slug: string;
  };
}

export interface Feature {
  icon: string;
  title: string;
  description: string;
}

export interface Tool {
  name: string;
  icon: string;
}

export interface Result {
  icon: string;
  value: string;
  label: string;
}

export interface GalleryImage {
  src: string;
  alt: string;
  type: 'desktop' | 'tablet' | 'mobile';
}

export interface Testimonial {
  text: string;
  author: string;
  role: string;
  company: string;
  avatar: string;
  rating: number;
}

export interface Service {
  id: string;
  icon: string;
  title: string;
  description: string;
  features: string[];
  featured?: boolean;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
  disabledFeatures?: string[];
  featured?: boolean;
  cta: string;
}

export interface AddOn {
  id: string;
  icon: string;
  title: string;
  price: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface Skill {
  name: string;
  icon: string;
}

export interface Stat {
  value: string;
  label: string;
}