import axios from 'axios';
import { ContactFormData } from '@/types';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

export const contactService = {
  sendMessage: async (data: ContactFormData) => {
    const response = await api.post('/contact', data);
    return response.data;
  },
};

export default api;