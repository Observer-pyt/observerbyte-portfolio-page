import { Service, PricingPlan, AddOn, Testimonial, Skill, Stat } from '@/types';

export const siteConfig = {
  name: 'ObserverByte',
  fullName: 'Abdulfatai Ibrahim Olamide',
  title: 'Full Stack Developer & Web Designer',
  email: 'olamideibrahim2021@gmail.com',
  phone: ['09039558115', '08126946708'],
  whatsapp: '2349039558115',
  social: {
    instagram: 'https://www.instagram.com/observer1559',
    tiktok: 'https://www.tiktok.com/@observer1559',
    threads: 'https://www.threads.net/@observer1559',
  },
  heroTitle: 'Building Full-Stack Web Solutions That Elevate Your Brand',
  heroSubtitle: 'I design and develop modern, scalable, and user-focused websites and applications.',
  aboutBio: `I'm Abdulfatai Ibrahim Olamide, also known as ObserverByte — a Full Stack Developer and Web Designer based in Nigeria. I specialize in building complete web solutions that combine clean frontend design with powerful backend functionality.`,
};

export const skills: Skill[] = [
  { name: 'HTML5', icon: 'html5' },
  { name: 'CSS3', icon: 'css3' },
  { name: 'JavaScript', icon: 'javascript' },
  { name: 'React', icon: 'react' },
  { name: 'WordPress', icon: 'wordpress' },
  { name: 'Elementor', icon: 'pencil-ruler' },
  { name: 'UI/UX', icon: 'palette' },
  { name: 'Backend', icon: 'database' },
];

export const stats: Stat[] = [
  { value: '50+', label: 'Projects Completed' },
  { value: '30+', label: 'Happy Clients' },
  { value: '3+', label: 'Years Experience' },
];

export const services: Service[] = [
  {
    id: 'web-design',
    icon: 'palette',
    title: 'Web Design',
    description: 'Creating beautiful, user-friendly interfaces that captivate your audience.',
    features: ['UI/UX Design', 'Responsive Layouts', 'Brand Integration', 'Prototyping'],
  },
  {
    id: 'frontend',
    icon: 'code',
    title: 'Frontend Development',
    description: 'Building pixel-perfect, performant websites with modern technologies.',
    features: ['HTML, CSS, JavaScript', 'React Development', 'WordPress/Elementor', 'Performance Optimization'],
  },
  {
    id: 'fullstack',
    icon: 'layers',
    title: 'Full Stack Development',
    description: 'Complete end-to-end web solutions from database to frontend.',
    features: ['Frontend & Backend', 'Database Design', 'API Integration', 'Deployment'],
    featured: true,
  },
  {
    id: 'redesign',
    icon: 'refresh-cw',
    title: 'Website Redesign',
    description: 'Modernize your existing website with fresh design and better performance.',
    features: ['Modern UI Update', 'Performance Boost', 'Mobile Optimization', 'SEO Enhancement'],
  },
];

export const pricingPlans: PricingPlan[] = [
  {
    id: 'basic',
    name: 'Basic',
    price: '₦50,000',
    description: 'Perfect for small businesses',
    features: ['Up to 5 Pages', 'Responsive Design', 'Basic SEO', 'Contact Form', '1 Month Support'],
    disabledFeatures: ['E-commerce', 'Custom Backend', 'Advanced Animations'],
    cta: 'Get Started',
  },
  {
    id: 'standard',
    name: 'Standard',
    price: '₦120,000',
    description: 'Great for growing businesses',
    features: ['Up to 10 Pages', 'Responsive Design', 'Advanced SEO', 'Forms & Booking', '3 Months Support', 'CMS Integration', 'Animations'],
    disabledFeatures: ['Custom Backend'],
    cta: 'Get Started',
  },
  {
    id: 'premium',
    name: 'Premium',
    price: '₦250,000',
    description: 'Complete solution',
    features: ['Unlimited Pages', 'Premium Design', 'Complete SEO', 'Advanced Features', '6 Months Support', 'E-commerce', 'Custom Backend', 'Premium Animations'],
    featured: true,
    cta: 'Get Started',
  },
];

export const addOns: AddOn[] = [
  { id: 'landing', icon: 'file-text', title: 'Landing Page', price: '₦30,000' },
  { id: 'redesign', icon: 'paint-roller', title: 'Website Redesign', price: '₦40,000+' },
  { id: 'logo', icon: 'palette', title: 'Logo Design', price: '₦15,000' },
  { id: 'maintenance', icon: 'tool', title: 'Maintenance', price: '₦20,000/mo' },
];

export const testimonials: Testimonial[] = [
  {
    text: 'ObserverByte delivered beyond expectations. Our new website increased inquiries by 300%.',
    author: 'Chukwudi Obi',
    role: 'CEO',
    company: 'Auto Cooling Solutions',
    avatar: 'https://ui-avatars.com/api/?name=Chukwudi+Obi&size=60&background=D4AF37&color=000',
    rating: 5,
  },
  {
    text: 'Professional and creative. Transformed our outdated website into a modern platform.',
    author: 'Dr. Patricia Adeola',
    role: 'Director',
    company: 'P Land Hospital',
    avatar: 'https://ui-avatars.com/api/?name=Patricia+Adeola&size=60&background=D4AF37&color=000',
    rating: 5,
  },
  {
    text: 'Seamless experience. He understood our vision perfectly.',
    author: 'Tunde Bakare',
    role: 'Founder',
    company: 'TechEd Academy',
    avatar: 'https://ui-avatars.com/api/?name=Tunde+Bakare&size=60&background=D4AF37&color=000',
    rating: 5,
  },
];