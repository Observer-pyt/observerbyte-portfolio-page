import { Project } from '@/types';

export const projects: Project[] = [
  {
    id: '1',
    slug: 'auto-cooling',
    title: 'ObserverByte Auto Cooling Website',
    shortDescription: 'A modern, conversion-focused website for automotive cooling solutions.',
    description: 'Complete website for a leading automotive cooling solutions provider.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=500&fit=crop',
    tags: ['Web Design', 'WordPress', 'Automotive'],
    client: 'Auto Cooling Solutions',
    timeline: '3 Weeks',
    year: '2024',
    role: 'Full Stack Developer',
    challenge: [
      'No online presence',
      'Difficulty reaching customers',
      'No online booking system',
      'Unable to showcase services',
    ],
    solution: [
      'Professional modern website',
      'SEO optimization',
      'WhatsApp booking integration',
      'Services showcase',
    ],
    tools: [
      { name: 'WordPress', icon: 'wordpress' },
      { name: 'Elementor', icon: 'pencil-ruler' },
      { name: 'Figma', icon: 'figma' },
    ],
    results: [
      { icon: 'trending-up', value: '300%', label: 'Increase in Inquiries' },
      { icon: 'smartphone', value: '98%', label: 'Mobile Score' },
      { icon: 'gauge', value: '95', label: 'PageSpeed' },
    ],
    testimonial: {
      text: 'ObserverByte delivered beyond expectations. Our website increased inquiries by 300%.',
      author: 'Chukwudi Obi',
      role: 'CEO',
      company: 'Auto Cooling Solutions',
      avatar: 'https://ui-avatars.com/api/?name=Chukwudi+Obi&size=60&background=D4AF37&color=000',
      rating: 5,
    },
    gallery: [
      { src: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1000&h=600&fit=crop', alt: 'Desktop', type: 'desktop' },
      { src: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=800&fit=crop', alt: 'Tablet', type: 'tablet' },
      { src: 'https://images.unsplash.com/photo-1555421689-3f034debb7a6?w=400&h=700&fit=crop', alt: 'Mobile', type: 'mobile' },
    ],
    beforeImage: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=1200&h=750&fit=crop&grayscale',
    afterImage: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=750&fit=crop',
    nextProject: { title: 'P Land Hospital', slug: 'pland-hospital' },
  },
  {
    id: '2',
    slug: 'pland-hospital',
    title: 'P Land Hospital Website',
    shortDescription: 'Healthcare platform with appointment booking.',
    description: 'Comprehensive website for a modern healthcare facility.',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=500&fit=crop',
    tags: ['Full Stack', 'Healthcare'],
    client: 'P Land Hospital',
    timeline: '5 Weeks',
    year: '2024',
    role: 'Full Stack Developer',
    challenge: ['Manual bookings', 'No online presence', 'Scattered patient info'],
    solution: ['Automated booking', 'Patient portal', 'SMS reminders'],
    tools: [
      { name: 'React', icon: 'react' },
      { name: 'Node.js', icon: 'nodejs' },
      { name: 'MongoDB', icon: 'database' },
    ],
    results: [
      { icon: 'calendar-plus', value: '500%', label: 'Online Bookings' },
      { icon: 'clock', value: '70%', label: 'Less Admin Time' },
    ],
    gallery: [
      { src: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1000&h=600&fit=crop', alt: 'Desktop', type: 'desktop' },
    ],
    beforeImage: 'https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?w=1200&h=750&fit=crop&grayscale',
    afterImage: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1200&h=750&fit=crop',
    nextProject: { title: 'Tech Dashboard', slug: 'tech-dashboard' },
  },
];

export const getProjectBySlug = (slug: string) => projects.find(p => p.slug === slug);