import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Check, Lightbulb, AlertTriangle } from 'lucide-react';
import { getProjectBySlug } from '@/data/projects';
import Button from '@/components/ui/Button';
import Card3D from '@/components/ui/Card3D';
import * as Icons from 'lucide-react';

const iconMap: { [key: string]: any } = {
  'trending-up': Icons.TrendingUp,
  smartphone: Icons.Smartphone,
  gauge: Icons.Gauge,
  search: Icons.Search,
  'calendar-plus': Icons.CalendarPlus,
  clock: Icons.Clock,
  'user-check': Icons.UserCheck,
  star: Icons.Star,
};

export default function CaseStudyPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const project = getProjectBySlug(slug!);

  useEffect(() => { window.scrollTo(0, 0); }, [slug]);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Project Not Found</h1>
          <Button onClick={() => navigate('/')}>Go Home</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="section-padding bg-gradient-to-b from-dark-50 to-white dark:from-dark-900 dark:to-dark-800">
        <div className="container-custom">
          <motion.button initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} onClick={() => navigate('/#projects')} className="flex items-center gap-2 text-gold-500 hover:gap-3 transition-all mb-8">
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Back to Projects</span>
          </motion.button>

          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="max-w-4xl">
            <div className="flex flex-wrap gap-2 mb-4">
              {project.tags.map((tag) => (
                <span key={tag} className="px-3 py-1 text-sm font-medium bg-gold-500/10 text-gold-600 dark:text-gold-400 rounded-full">{tag}</span>
              ))}
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">{project.title}</h1>
            <p className="text-xl text-dark-500 dark:text-gray-400 mb-8">{project.description}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {[
                { label: 'Client', value: project.client },
                { label: 'Timeline', value: project.timeline },
                { label: 'Year', value: project.year },
                { label: 'Role', value: project.role },
              ].map((meta) => (
                <div key={meta.label}>
                  <p className="text-sm text-dark-400 dark:text-gray-500 uppercase tracking-wider mb-1">{meta.label}</p>
                  <p className="font-semibold">{meta.value}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container-custom">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="relative rounded-2xl overflow-hidden shadow-2xl">
            <div className="aspect-video bg-dark-900 p-4">
              <img src={project.image} alt={project.title} className="w-full h-full object-cover rounded-lg" />
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section-padding bg-dark-50 dark:bg-dark-900">
        <div className="container-custom">
          <div className="grid lg:grid-cols-2 gap-8">
            <Card3D>
              <div className="bg-white dark:bg-dark-800 p-8 rounded-2xl border-l-4 border-red-500 h-full">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-red-500/10 rounded-lg flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-red-500" />
                  </div>
                  <h2 className="text-2xl font-bold">The Challenge</h2>
                </div>
                <ul className="space-y-3">
                  {project.challenge.map((item, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                      <span className="text-dark-600 dark:text-gray-300">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Card3D>

            <Card3D>
              <div className="bg-white dark:bg-dark-800 p-8 rounded-2xl border-l-4 border-gold-500 h-full">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-gold-500/10 rounded-lg flex items-center justify-center">
                    <Lightbulb className="w-6 h-6 text-gold-500" />
                  </div>
                  <h2 className="text-2xl font-bold">The Solution</h2>
                </div>
                <ul className="space-y-3">
                  {project.solution.map((item, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-gold-500 flex-shrink-0 mt-0.5" />
                      <span className="text-dark-600 dark:text-gray-300">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Card3D>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container-custom">
          <h2 className="text-3xl font-bold text-center mb-12">Tools & Technologies</h2>
          <div className="flex flex-wrap justify-center gap-4">
            {project.tools.map((tool, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                whileHover={{ scale: 1.1 }}
                className="px-6 py-3 bg-white dark:bg-dark-800 rounded-lg border border-dark-100 dark:border-dark-700 hover:border-gold-500 transition-colors"
              >
                <span className="font-medium">{tool.name}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding bg-dark-50 dark:bg-dark-900">
        <div className="container-custom">
          <h2 className="text-3xl font-bold text-center mb-12">Results & Outcomes</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {project.results.map((result, i) => {
              const Icon = iconMap[result.icon] || Icons.TrendingUp;
              return (
                <Card3D key={i}>
                  <div className="bg-white dark:bg-dark-800 p-6 rounded-xl text-center border border-dark-100 dark:border-dark-700">
                    <div className="w-16 h-16 mx-auto mb-4 bg-gold-500/10 rounded-full flex items-center justify-center">
                      <Icon className="w-8 h-8 text-gold-500" />
                    </div>
                    <h3 className="text-3xl font-bold text-gradient mb-2">{result.value}</h3>
                    <p className="text-dark-500 dark:text-gray-400 text-sm">{result.label}</p>
                  </div>
                </Card3D>
              );
            })}
          </div>

          {project.testimonial && (
            <div className="max-w-4xl mx-auto bg-gradient-to-br from-gold-500/10 to-gold-600/5 p-8 md:p-12 rounded-2xl border border-gold-500/20">
              <div className="flex items-start gap-4 mb-6">
                <img src={project.testimonial.avatar} alt={project.testimonial.author} className="w-16 h-16 rounded-full border-2 border-gold-500" />
                <div>
                  <h4 className="font-bold text-lg">{project.testimonial.author}</h4>
                  <p className="text-dark-500 dark:text-gray-400 text-sm">{project.testimonial.role}, {project.testimonial.company}</p>
                </div>
              </div>
              <p className="text-xl italic text-dark-700 dark:text-gray-300 leading-relaxed">"{project.testimonial.text}"</p>
            </div>
          )}
        </div>
      </section>

      {project.nextProject && (
        <section className="section-padding">
          <div className="container-custom text-center">
            <span className="text-sm font-semibold uppercase tracking-widest text-gold-500 mb-3 block">Next Project</span>
            <h2 className="text-3xl font-bold mb-6">{project.nextProject.title}</h2>
            <Button variant="primary" size="lg" onClick={() => navigate(`/case-study/${project.nextProject!.slug}`)}>
              View Case Study
            </Button>
          </div>
        </section>
      )}
    </div>
  );
}